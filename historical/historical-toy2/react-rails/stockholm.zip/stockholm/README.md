Stockholm is a demo app that use ruby and react via `react-rails` gem.
