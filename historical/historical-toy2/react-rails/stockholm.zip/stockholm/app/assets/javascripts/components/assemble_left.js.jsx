var AssembleLeft = React.createClass({

  render: function() {
    return <div>left component</div>;
  }
});
