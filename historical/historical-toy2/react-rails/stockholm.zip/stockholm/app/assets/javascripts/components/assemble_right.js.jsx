var AssembleRight = React.createClass({

  render: function() {
    return <div>right component</div>;
  }
});
