var AssembleUp = React.createClass({

  render: function() {
    return <div>up component</div>;
  }
});
