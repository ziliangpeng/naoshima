var AssembleDown = React.createClass({

  render: function() {
    return <div>down component</div>;
  }
});
