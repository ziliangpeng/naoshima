class AssembleController < ApplicationController
  def demo
  end
end
